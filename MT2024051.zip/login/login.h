#ifndef LOGIN_STATUS_H
#define LOGIN_STATUS_H

int is_customer_logged_in(int customer_id);
void set_logged_in_status(int customer_id);

#endif // LOGIN_STATUS_H